enum StoriesCacheType {
  Stories = 'stories',
  Pinned = 'pinnedStories',
  Archive = 'archiveStories'
}

export default StoriesCacheType;
