export default function isAnyChat(peerId: PeerId) {
  return +peerId < 0;
}
