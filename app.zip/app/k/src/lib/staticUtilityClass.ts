export default class StaticUtilityClass {
  constructor() {
    throw new Error('Cannot instantiate a static utility class');
  }
}
