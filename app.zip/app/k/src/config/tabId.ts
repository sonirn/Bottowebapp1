const tabId = Date.now() % Math.random() * 100000000 | 0;
export default tabId;
