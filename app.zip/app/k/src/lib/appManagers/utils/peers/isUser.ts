export default function isUser(peerId: PeerId) {
  return +peerId >= 0;
}
