export const generateDelimiter = () => {
  const delimiter = document.createElement('div');
  delimiter.classList.add('gradient-delimiter');
  return delimiter;
};
