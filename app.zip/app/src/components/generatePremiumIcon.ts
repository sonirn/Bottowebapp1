import Icon from './icon';

export default function generatePremiumIcon() {
  const span = Icon('star', 'premium-icon');
  return span;
}
