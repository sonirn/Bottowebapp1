export const CURRENT_ACCOUNT_QUERY_PARAM = 'account';

export const MAX_ACCOUNTS_FREE = 3;
export const MAX_ACCOUNTS_PREMIUM = 4;
export const MAX_ACCOUNTS = MAX_ACCOUNTS_PREMIUM;
