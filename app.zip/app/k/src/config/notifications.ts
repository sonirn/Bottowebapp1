export const NOTIFICATION_ICON_PATH = 'assets/img/logo_filled_rounded.png';
export const NOTIFICATION_BADGE_PATH = 'assets/img/logo_plain.svg'; // masked
