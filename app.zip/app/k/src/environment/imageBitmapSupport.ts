const IS_IMAGE_BITMAP_SUPPORTED = typeof(ImageBitmap) !== 'undefined';

export default IS_IMAGE_BITMAP_SUPPORTED;
