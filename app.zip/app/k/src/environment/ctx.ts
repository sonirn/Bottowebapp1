const ctx = typeof(window) !== 'undefined' ? window : self;

export default ctx;
