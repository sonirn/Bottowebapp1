export const cnTopbarLive = (className = '') => `pinned-live${className}`;
